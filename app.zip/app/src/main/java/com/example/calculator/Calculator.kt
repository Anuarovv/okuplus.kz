package com.example.calculator

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import kotlinx.android.synthetic.main.activity_main.*
import net.objecthunter.exp4j.ExpressionBuilder

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        //Numbers
        tvOne.setOnClickListener
        run { appendOnExpresstion("1", true) }
        tvTwo.setOnClickListener
        run { appendOnExpresstion("2", true) }
        tvThree.setOnClickListener
        run { appendOnExpresstion("3", true) }
        tvFour.setOnClickListener
        run { appendOnExpresstion("4", true) }
        tvFive.setOnClickListener
        run { appendOnExpresstion("5", true) }
        tvSix.setOnClickListener
        run { appendOnExpresstion("6", true) }
        tvSeven.setOnClickListener
        run { appendOnExpresstion("7", true) }
        tvEight.setOnClickListener
        run { appendOnExpresstion("8", true) }
        tvNine.setOnClickListener
        run { appendOnExpresstion("9", true) }
        tvZero.setOnClickListener
        run { appendOnExpresstion("0", true) }
        tvDot.setOnClickListener
        run { appendOnExpresstion(".", true) }

        //Operators
        tvPlus.setOnClickListener
        run { appendOnExpresstion("+", false) }
        tvMinus.setOnClickListener
        run { appendOnExpresstion("-", false) }
        tvMul.setOnClickListener
        run { appendOnExpresstion("*", false) }
        tvDivide.setOnClickListener
        run { appendOnExpresstion("/", false) }
        tvOpen.setOnClickListener
        run { appendOnExpresstion("(", false) }
        tvClose.setOnClickListener
        run { appendOnExpresstion(")", false) }

        tvClear.setOnClickListener
        run {
            tvExpression.text = ""
            tvResult.text = ""
        }

        tvBack.setOnClickListener
        run {
            val string = tvExpression.text.toString()
            if (string.isNotEmpty()) {
                tvExpression.text = string.substring(0, string.length - 1)
            }
            tvResult.text = ""
        }

        tvEquals.setOnClickListener
        run {
            try {

                val expression = ExpressionBuilder(tvExpression.text.toString()).build()
                val result = expression.evaluate()
                val longResult = result.toLong()
                if (result === longResult.toDouble())
                    tvResult.text = longResult.toString()
                else
                    tvResult.text = result.toString()

            }


            Exception
            run { Log.d("Exception", " message : " + e.message) }
        }

    }

    internal fun appendOnExpresstion(): `fun` {

        if (tvResult.text.isNotEmpty()) {
            tvExpression.text = ""
        }

        if (canClear) {
            tvResult.text = ""
            tvExpression.append(string)
        } else {
            tvExpression.append(tvResult.text)
            tvExpression.append(string)
            tvResult.text = ""
        }
    }

}
